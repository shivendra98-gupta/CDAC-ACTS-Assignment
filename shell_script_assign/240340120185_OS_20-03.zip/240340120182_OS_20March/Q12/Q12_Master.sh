#!/bin/bash

# Check if "master" file exists
if [ ! -f "master.txt" ]; then
    echo "Error: 'master' file not found."
    exit 1
fi

# Read the batch code from the user
read -p "Enter batch code: " batch_code

# Search for the batch code in the "master" file
grep_result=$(grep "^$batch_code|" master.txt)

if [ -z "$grep_result" ]; then
    echo "Batch code not found in 'master' file."
    exit 1
fi

# Get the current number of students for the batch
number_of_students=$(echo "$grep_result" | cut -d "|" -f 3)

# Allow the user to enter records
while true; do
    read -p "Enter RollNo, Name, Hindi Marks, Maths Marks, Physics Marks (separated by spaces, 'q' to quit): " record
    if [ "$record" == "q" ]; then
        break
    fi
    echo "$record" >> "$batch_code"
    number_of_students=$((number_of_students + 1))
done

# Update the number of students in the "master" file
sed -i "s/^$batch_code|.*|.*$/$batch_code|\1|$number_of_students/g" >  master.txt
#sed -i "/^$batch_code|/s/|[0-9]*$/|$number_of_students/"  master.txt
echo "Records added successfully for batch code $batch_code."

