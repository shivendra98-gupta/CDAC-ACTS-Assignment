#!/bin/bash

<<Assignment3
Display the name of files in the current directory along with the names of files with maximum & minimum size. The file size is considered in bytes.
Assignment3

ls -l | awk '{print $5,$9}' | sort -n | awk 'NR==2{print "Minimum Sized File : " $2} END {print "Minimum Sized File : " $2}'
